# AI Trading Content Factory

Educational trading-content automation for Bullseye Theory.

The starter pipeline generates educational drafts, runs basic safety checks, and saves drafts for human approval.

Current mode: MOCK_MODE=true. No brokerage orders or trade execution are performed.

Flow:
Topic discovery -> research -> fact review -> script -> safety check -> visual plan -> caption/hashtags -> approval queue.

Secrets must be stored in GitHub Actions Secrets, never in source files.
