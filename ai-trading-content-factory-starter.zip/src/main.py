import json
import os
from pathlib import Path
from datetime import datetime, timezone

BRAND = "Bullseye Theory"
OUTPUT_DIR = Path("output")
MOCK_MODE = os.getenv("MOCK_MODE", "true").lower() == "true"
DISCLAIMER = "Educational content only. Not financial advice. Examples are illustrative and not personalized recommendations."

TOPICS = [
    {"title": "What Is a Support Level in Trading?", "slug": "support-level", "source_type": "controlled_educational_topic"},
    {"title": "3 Common Mistakes Beginner Traders Make", "slug": "beginner-trading-mistakes", "source_type": "controlled_educational_topic"},
]

SOURCE_MAP = {
    "support-level": [
        {"name": "Fidelity — What Is Support And Resistance?", "url": "https://www.fidelity.com/learning-center/trading-investing/technical-analysis/support-and-resistance"},
        {"name": "Fidelity — What Is Technical Analysis?", "url": "https://www.fidelity.com/learning-center/trading-investing/technical-analysis/what-is-technical-analysis"},
    ],
    "beginner-trading-mistakes": [
        {"name": "Fidelity — What Is Technical Analysis?", "url": "https://www.fidelity.com/learning-center/trading-investing/technical-analysis/what-is-technical-analysis"},
    ],
}

def trend_discovery():
    return TOPICS

def research(topic):
    if topic["slug"] == "support-level":
        summary = "A support level is a price area where buying interest may be strong enough to slow or stop a decline. Support is an area, not a guaranteed floor, and it can fail."
        key_points = [
            "Support is better treated as a price area than a perfectly exact number.",
            "A support area can fail when selling pressure overwhelms demand.",
            "Technical analysis is not an exact science.",
        ]
    else:
        summary = "Beginner traders can make avoidable process mistakes such as entering without a defined plan, risking too much on one idea, and treating a single chart signal as certainty."
        key_points = [
            "Define the trade idea and invalidation before entering.",
            "Avoid treating one indicator or pattern as a guarantee.",
            "Use consistent risk controls and review decisions afterward.",
        ]
    return {"summary": summary, "key_points": key_points, "sources": SOURCE_MAP[topic["slug"]], "research_status": "controlled_educational_reference"}

def fact_check(research_data):
    return {"status": "review_required", "verified_by": "controlled educational references", "notes": ["No live market claim was made.", "Human review is required before publication."]}

def script_generation(topic, research_data):
    return "\n".join([
        f"Hook: {topic['title']}",
        f"Explain: {research_data['summary']}",
        "Key points:",
        *[f"- {p}" for p in research_data["key_points"]],
        f"Close: Save this for your trading education notes. {DISCLAIMER}",
    ])

def safety_check(script):
    blocked = ["guaranteed profit", "guaranteed returns", "risk-free", "sure win", "buy now", "sell now"]
    hits = [p for p in blocked if p in script.lower()]
    return {"status": "pass" if not hits else "blocked", "blocked_phrases_found": hits}

def visual_plan(topic):
    return {
        "format": "9:16 short-form video",
        "scenes": ["Title card", "Simple chart-style illustration", "Teaching points", "Educational disclaimer"],
        "avoid": ["profit guarantees", "personalized trade instructions", "fake performance screenshots"],
    }

def caption_and_hashtags(topic):
    return {
        "caption": f"{topic['title']} — a simple educational breakdown for beginner traders. Use this as a learning note, not as a trade signal.\n\n{DISCLAIMER}",
        "hashtags": ["#TradingEducation", "#TechnicalAnalysis", "#StockMarket", "#TradingForBeginners", "#RiskManagement", "#BullseyeTheory"],
    }

def build_content(content_id, topic):
    r = research(topic)
    f = fact_check(r)
    script = script_generation(topic, r)
    safety = safety_check(script)
    return {
        "content_id": content_id,
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "brand": BRAND,
        "status": "pending_approval" if safety["status"] == "pass" else "blocked",
        "topic": {"title": topic["title"], "slug": topic["slug"], "source": topic["source_type"]},
        "research": r,
        "fact_check": f,
        "script": script,
        "safety_check": safety,
        "visual_plan": visual_plan(topic),
        "social": caption_and_hashtags(topic),
        "disclaimer": DISCLAIMER,
        "mock_mode": MOCK_MODE,
    }

def main():
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    items = []
    for i, topic in enumerate(trend_discovery(), 1):
        item = build_content(f"content_{i}", topic)
        items.append(item)
        (OUTPUT_DIR / f"content_{i}.json").write_text(json.dumps(item, indent=2, ensure_ascii=False), encoding="utf-8")
    queue = {
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "status": "awaiting_human_approval",
        "items": [{"content_id": x["content_id"], "status": x["status"], "topic": x["topic"]["title"]} for x in items],
    }
    (OUTPUT_DIR / "approval_queue.json").write_text(json.dumps(queue, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"Generated {len(items)} educational drafts. MOCK_MODE={MOCK_MODE}")

if __name__ == "__main__":
    main()
